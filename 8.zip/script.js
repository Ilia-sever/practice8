
function f4() 
{
	let elems=document.body.getElementsByTagName('*');


	document.getElementsByTagName('input')[0].addEventListener("change", function () 
		{
			let fin=this.value;
			for (let i=0;i<elems.length;i++) 
			{
				if ((elems[i].textContent.indexOf(fin)!=-1)&&(fin!='')&&(elems[i].tagName=="H1"||elems[i].tagName=="H3"||elems[i].tagName=="H4"||elems[i].tagName=="P"||elems[i].tagName=="A"))
				elems[i].innerHTML=elems[i].innerHTML.replace(RegExp(fin, 'g'),"<mark>"+fin+"</mark>")
			}
		}
	)

	document.getElementsByTagName('html')[0].addEventListener("keydown", function (event) 
			{
				//alert(event.keyCode);
				if (event.keyCode == "67") 
				{
					for (let i=0;i<elems.length;i++) 
					{
						if (elems[i].innerHTML.indexOf("<mark>")!=-1)
						{
							elems[i].innerHTML=elems[i].innerHTML.replace(/<mark>/g,"");
							elems[i].innerHTML=elems[i].innerHTML.replace(/<\/mark>/g,"");
						}
					}
				}
			}
	)



}